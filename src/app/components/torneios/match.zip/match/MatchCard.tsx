import MatchTeam from "./MatchTeam";
import MatchDateStatus from "./MatchDateStatus";

interface MatchProps {
  match: {
    date: string;
    status: string;
    team1: { logo: string; name: string };
    team2: { logo: string; name: string };
    score?: string | null;
  };
}


const MatchCard: React.FC<MatchProps> = ({ match }) => { 
  return (
    <div className="p-4 bg-gray-100 rounded-lg shadow-md">
      <MatchDateStatus date={match.date} status={match.status} />

      <div className="mt-3 flex justify-between items-center">
        <MatchTeam logo={match.team1.logo} name={match.team1.name} />

        {match.score ? (
          <span className="text-xl font-bold text-gray-900">{match.score}</span>
        ) : (
          <span className="text-gray-500">vs</span>
        )}

        <MatchTeam logo={match.team2.logo} name={match.team2.name} />
      </div>
    </div>
  );
};

export default MatchCard;
