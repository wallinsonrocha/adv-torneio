import Image from "next/image";

interface MatchTeamProps {
  logo: string;
  name: string;
}

const MatchTeam: React.FC<MatchTeamProps> = ({ logo, name }) => {
  return (
    <div className="flex items-center space-x-3">
      <Image width={40} height={40} src={logo} alt={name} className="rounded-full" />
      <p className="text-gray-800 font-semibold">{name}</p>
    </div>
  );
};

export default MatchTeam;
