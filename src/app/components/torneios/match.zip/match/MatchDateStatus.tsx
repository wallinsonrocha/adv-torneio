import Image from "next/image";

interface MatchDateStatusProps {
  date: string;
  status: string;
}

const MatchDateStatus: React.FC<MatchDateStatusProps> = ({ date, status }) => {
  return (
    <div>
      <div className="flex gap-2">
        <Image width={16} height={16} src="/icons/torneios/calendar.svg" alt="Calendário" />
        <p className="text-gray-700 font-medium">{date}</p>
      </div>
      <p className={`text-sm ${status === "Finalizado" ? "text-green-600" : "text-yellow-600"}`}>
        {status}
      </p>
    </div>
  );
};

export default MatchDateStatus;
